import asyncio

import pygame
import random
import math
from pathlib import Path

pygame.init()

# CONFIGURACAO DA TELA
LARGURA, ALTURA = 1000, 650
TELA = pygame.display.set_mode((LARGURA, ALTURA))
pygame.display.set_caption("Missao Reciclagem - Parque Sustentavel")

RELOGIO = pygame.time.Clock()
FONTE = pygame.font.SysFont("Arial", 18, bold=True)
TITULO = pygame.font.SysFont("Arial", 30, bold=True)

# CORES
BRANCO = (255, 255, 255)
PRETO = (25, 25, 25)
VERDE = (55, 135, 65)
VERDE_ESCURO = (25, 85, 40)
AZUL = (35, 110, 220)
VERMELHO = (215, 50, 50)
AMARELO = (235, 190, 30)
CINZA = (105, 105, 105)

# CARREGAMENTO DAS IMAGENS
PASTA = Path(__file__).parent / "assets"

arquivos = {
    "Papel": "jornal.png",
    "Plastico": "garrafa_pet.png",
    "Metal": "lata.png",
    "Vidro": "garrafa_vidro.png"
}

imagens = {}

for tipo, arquivo in arquivos.items():
    caminho = PASTA / arquivo
    if caminho.exists():
        imagem = pygame.image.load(str(caminho)).convert_alpha()
        imagens[tipo] = imagem

# JOGADOR
jogador_x = 0.0
jogador_z = 0.78
velocidade = 0.65
tempo_animacao = 0

# PONTUACAO E INVENTARIO
pontos = 0


# SISTEMA DE MISSOES
missoes = {
    "Plastico": 0,
    "Papel": 0,
    "Metal": 0
}

meta_missoes = {
    "Plastico": 5,
    "Papel": 5,
    "Metal": 3
}

inventario = {
    "Papel": 0,
    "Plastico": 0,
    "Metal": 0,
    "Vidro": 0
}

mensagem = "Ajude a limpar o parque!"

# LIXEIRAS
lixeiras = [
    {"tipo": "Papel", "x": -0.72, "z": 0.72, "cor": AZUL},
    {"tipo": "Plastico", "x": -0.25, "z": 0.72, "cor": VERMELHO},
    {"tipo": "Metal", "x": 0.25, "z": 0.72, "cor": AMARELO},
    {"tipo": "Vidro", "x": 0.72, "z": 0.72, "cor": VERDE_ESCURO}
]

# OBJETOS RECICLAVEIS
objetos = []

tipos = ["Papel", "Plastico", "Metal", "Vidro"]

for tipo in tipos:
    for i in range(8):
        objetos.append({
            "tipo": tipo,
            "x": random.uniform(-0.85, 0.85),
            "z": random.uniform(0.12, 0.85)
        })

random.shuffle(objetos)
def projetar(x, z):
    profundidade = max(0.1, min(1.0, z))
    escala = 0.35 + profundidade * 0.85

    tela_x = LARGURA / 2 + x * (100 + profundidade * 330)
    tela_y = 165 + profundidade * 390

    return int(tela_x), int(tela_y), escala


def desenhar_arvore(x, z):
    px, py, escala = projetar(x, z)

    tronco = max(5, int(17 * escala))
    copa = max(18, int(40 * escala))

    pygame.draw.ellipse(
        TELA, (45, 95, 45),
        (px - copa, py - copa * 2,
         copa * 2, copa * 2.5)
    )

    pygame.draw.rect(
        TELA, (105, 65, 35),
        (px - tronco // 2, py - copa,
         tronco, copa)
    )

    pygame.draw.circle(
        TELA, (35, 115, 45),
        (px, py - copa), copa
    )

    pygame.draw.circle(
        TELA, (55, 145, 60),
        (px - copa // 3, py - copa - copa // 3),
        max(6, copa // 2)
    )


def desenhar_banco(x, z):
    px, py, escala = projetar(x, z)

    largura = int(65 * escala)
    altura = int(10 * escala)

    pygame.draw.rect(
        TELA, (110, 65, 30),
        (px - largura // 2, py - altura,
         largura, altura)
    )

    pygame.draw.rect(
        TELA, (75, 45, 25),
        (px - largura // 2, py - altura * 2,
         largura, max(4, altura // 2))
    )

    pygame.draw.line(
        TELA, (65, 65, 65),
        (px - largura // 3, py),
        (px - largura // 3, py - altura),
        max(2, int(4 * escala))
    )

    pygame.draw.line(
        TELA, (65, 65, 65),
        (px + largura // 3, py),
        (px + largura // 3, py - altura),
        max(2, int(4 * escala))
    )


def desenhar_parque():
    TELA.fill((125, 190, 230))

    # SOL
    pygame.draw.circle(TELA, (255, 225, 110), (850, 80), 42)

    # MONTANHAS AO FUNDO
    pygame.draw.polygon(
        TELA, (100, 150, 115),
        [(0, 190), (150, 125), (300, 190),
         (480, 115), (650, 190), (820, 130),
         (1000, 190), (1000, 250), (0, 250)]
    )

    # GRAMA
    pygame.draw.rect(
        TELA, (85, 155, 70),
        (0, 190, LARGURA, 460)
    )

    # CAMINHO EM PERSPECTIVA
    pygame.draw.polygon(
        TELA, (155, 145, 125),
        [(420, 155), (580, 155), (900, 650), (100, 650)]
    )

    pygame.draw.polygon(
        TELA, (190, 180, 160),
        [(455, 155), (545, 155), (760, 650), (240, 650)]
    )

    # DETALHES DA GRAMA
    random.seed(12)
    for i in range(180):
        x = random.randint(0, LARGURA)
        y = random.randint(200, ALTURA)
        pygame.draw.line(
            TELA, (65, 135, 55),
            (x, y), (x + 2, y - 5), 1
        )

    # ARVORES
    for x, z in [
        (-1.0, 0.25), (-0.85, 0.48), (-1.0, 0.78),
        (1.0, 0.25), (0.9, 0.48), (1.0, 0.82),
        (-0.55, 0.18), (0.65, 0.18)
    ]:
        desenhar_arvore(x, z)

    # BANCOS
    desenhar_banco(-0.65, 0.45)
    desenhar_banco(0.65, 0.40)


def desenhar_jogador():
    px, py, escala = projetar(jogador_x, jogador_z)

    t = tempo_animacao
    movimento = math.sin(t * 12) * 7

    tam = escala

    # SOMBRA
    pygame.draw.ellipse(
        TELA, (55, 65, 45),
        (px - int(27 * tam), py - 3,
         int(54 * tam), int(13 * tam))
    )

    # PERNAS ANIMADAS
    perna = movimento * tam

    pygame.draw.line(
        TELA, (35, 45, 90),
        (px - int(9 * tam), py - int(12 * tam)),
        (px - int(13 * tam) + int(perna),
         py + int(24 * tam)),
        max(5, int(12 * tam))
    )

    pygame.draw.line(
        TELA, (35, 45, 90),
        (px + int(9 * tam), py - int(12 * tam)),
        (px + int(13 * tam) - int(perna),
         py + int(24 * tam)),
        max(5, int(12 * tam))
    )

    # SAPATOS
    pygame.draw.ellipse(
        TELA, (35, 30, 25),
        (px - int(25 * tam) + int(perna),
         py + int(19 * tam),
         int(22 * tam), int(11 * tam))
    )

    pygame.draw.ellipse(
        TELA, (35, 30, 25),
        (px + int(4 * tam) - int(perna),
         py + int(19 * tam),
         int(22 * tam), int(11 * tam))
    )

    # CORPO / UNIFORME
    pygame.draw.rect(
        TELA, (35, 105, 55),
        (px - int(23 * tam), py - int(70 * tam),
         int(46 * tam), int(60 * tam)),
        border_radius=9
    )

    # FAIXA REFLETIVA
    pygame.draw.rect(
        TELA, (220, 210, 80),
        (px - int(22 * tam), py - int(32 * tam),
         int(44 * tam), max(3, int(6 * tam)))
    )

    # MOCHILA
    pygame.draw.rect(
        TELA, (125, 75, 35),
        (px - int(17 * tam), py - int(67 * tam),
         int(34 * tam), int(38 * tam)),
        border_radius=7
    )

    pygame.draw.rect(
        TELA, (90, 50, 25),
        (px - int(10 * tam), py - int(35 * tam),
         int(20 * tam), int(6 * tam)),
        border_radius=3
    )

    # BRACOS ANIMADOS
    pygame.draw.line(
        TELA, (190, 130, 90),
        (px - int(21 * tam), py - int(55 * tam)),
        (px - int(30 * tam), py - int(20 * tam) + int(perna)),
        max(4, int(9 * tam))
    )

    pygame.draw.line(
        TELA, (190, 130, 90),
        (px + int(21 * tam), py - int(55 * tam)),
        (px + int(30 * tam), py - int(20 * tam) - int(perna)),
        max(4, int(9 * tam))
    )

    # PESCOCO E CABECA
    pygame.draw.circle(
        TELA, (195, 140, 100),
        (px, py - int(75 * tam)),
        max(8, int(17 * tam))
    )

    # CABELO
    pygame.draw.arc(
        TELA, (40, 25, 15),
        (px - int(17 * tam), py - int(94 * tam),
         int(34 * tam), int(27 * tam)),
        0, math.pi, max(4, int(7 * tam))
    )

    # BONE
    pygame.draw.arc(
        TELA, (35, 65, 35),
        (px - int(19 * tam), py - int(102 * tam),
         int(38 * tam), int(22 * tam)),
        math.pi, math.tau, max(4, int(8 * tam))
    )

    pygame.draw.line(
        TELA, (35, 65, 35),
        (px - int(20 * tam), py - int(91 * tam)),
        (px + int(20 * tam), py - int(91 * tam)),
        max(3, int(5 * tam))
    )


def desenhar_objeto(objeto):
    px, py, escala = projetar(objeto["x"], objeto["z"])
    tipo = objeto["tipo"]

    if tipo in imagens:
        largura = max(12, int(32 * escala))
        altura = max(12, int(32 * escala))

        imagem = pygame.transform.smoothscale(
            imagens[tipo], (largura, altura)
        )

        TELA.blit(
            imagem,
            (px - largura // 2, py - altura // 2)
        )
    else:
        cores = {
            "Papel": BRANCO,
            "Plastico": AZUL,
            "Metal": CINZA,
            "Vidro": VERDE_ESCURO
        }

        pygame.draw.circle(
            TELA, cores[tipo], (px, py),
            max(5, int(10 * escala))
        )


def desenhar_lixeira(lixeira):
    px, py, escala = projetar(lixeira["x"], lixeira["z"])

    largura = int(42 * escala)
    altura = int(55 * escala)

    pygame.draw.rect(
        TELA, lixeira["cor"],
        (px - largura // 2, py - altura,
         largura, altura),
        border_radius=5
    )

    pygame.draw.rect(
        TELA, (35, 35, 35),
        (px - largura // 2 - 3, py - altura,
         largura + 6, max(5, int(7 * escala)))
    )

    texto = pygame.font.SysFont(
        "Arial", max(9, int(12 * escala)), bold=True
    ).render(lixeira["tipo"], True, BRANCO)

    TELA.blit(
        texto,
        (px - texto.get_width() // 2, py - altura // 2)
    )


def desenhar_interface():
    pygame.draw.rect(
        TELA, (20, 55, 35),
        (0, 0, LARGURA, 105)
    )

    titulo = TITULO.render(
        "MISSAO RECICLAGEM", True, BRANCO
    )
    TELA.blit(titulo, (25, 10))

    texto_pontos = FONTE.render(
        f"PONTOS: {pontos}", True, AMARELO
    )
    TELA.blit(texto_pontos, (25, 58))

    texto_inv = FONTE.render(
        f"Papel: {inventario['Papel']}   "
        f"Plastico: {inventario['Plastico']}   "
        f"Metal: {inventario['Metal']}   "
        f"Vidro: {inventario['Vidro']}",
        True, BRANCO
    )
    TELA.blit(texto_inv, (230, 58))
    texto_missoes = FONTE.render(
        f"Missoes: Plastico {missoes['Plastico']}/5  "
        f"Papel {missoes['Papel']}/5  "
        f"Metal {missoes['Metal']}/3",
        True, AMARELO
    )
    TELA.blit(texto_missoes, (520, 58))
    if missao_concluida:
        texto_concluida = FONTE.render(missao_concluida, True, AMARELO)
        TELA.blit(texto_concluida, (25, 150))

    aviso = FONTE.render(mensagem, True, BRANCO)
    TELA.blit(aviso, (25, 115))

    controles = FONTE.render(
        "WASD / SETAS: MOVIMENTAR     E: DEPOSITAR",
        True, BRANCO
    )
    TELA.blit(controles, (25, 615))


missao_concluida = ""
recompensa_recebida = False
def coletar_objetos():
    global mensagem, missoes, missao_concluida
    global pontos, recompensa_recebida

    for objeto in objetos[:]:
        distancia = math.sqrt(
            (jogador_x - objeto["x"]) ** 2 +
            (jogador_z - objeto["z"]) ** 2
        )

        if distancia < 0.09:
            tipo = objeto["tipo"]

            inventario[tipo] += 1
            objetos.remove(objeto)

            if tipo in ("Plastico", "Papel", "Metal"):
                missoes[tipo] = min(
                    missoes[tipo] + 1,
                    meta_missoes[tipo]
                )

                if missoes[tipo] >= meta_missoes[tipo]:
                    missao_concluida = f"MISSAO CONCLUIDA: {tipo}!"

                if (
                    all(
                        missoes[t] >= meta_missoes[t]
                        for t in meta_missoes
                    )
                    and not recompensa_recebida
                ):
                    pontos += 500
                    recompensa_recebida = True
                    mensagem = "PARABENS! VOCE GANHOU 500 PONTOS!"

            if not recompensa_recebida:
                mensagem = f"Material coletado: {tipo}!"


def depositar_material():
    global pontos, mensagem

    for lixeira in lixeiras:
        distancia = math.sqrt(
            (jogador_x - lixeira["x"]) ** 2 +
            (jogador_z - lixeira["z"]) ** 2
        )

        if distancia < 0.16:
            tipo = lixeira["tipo"]

            if inventario[tipo] > 0:
                quantidade = inventario[tipo]

                pontos += quantidade * 20
                inventario[tipo] = 0

                mensagem = (
                    f"{tipo} reciclado! "
                    f"+{quantidade * 20} pontos!"
                )
            else:
                mensagem = f"Voce nao tem material: {tipo}."

            return

    mensagem = "Aproxime-se de uma lixeira!"


def desenhar_menu(selecao=0):
    desenhar_parque()

    # Painel central
    painel = pygame.Surface((560, 390), pygame.SRCALPHA)
    painel.fill((15, 45, 25, 225))
    TELA.blit(painel, (220, 125))

    titulo = TITULO.render("MISSAO RECICLAGEM", True, BRANCO)
    TELA.blit(titulo, (LARGURA // 2 - titulo.get_width() // 2, 165))

    subtitulo = FONTE.render(
        "Ajude a preservar o meio ambiente!",
        True, (210, 235, 210)
    )
    TELA.blit(
        subtitulo,
        (LARGURA // 2 - subtitulo.get_width() // 2, 215)
    )

    botoes = [
        ("JOGAR", 290),
        ("INSTRUCOES", 365),
        ("SAIR", 440)
    ]

    for nome, y in botoes:
        retangulo = pygame.Rect(370, y, 260, 55)
        cor_botao = (65, 165, 85) if nome == ("JOGAR", "INSTRUCOES", "SAIR")[selecao] else (45, 125, 65)
        pygame.draw.rect(TELA, cor_botao, retangulo, border_radius=12)
        pygame.draw.rect(TELA, AMARELO if nome == ("JOGAR", "INSTRUCOES", "SAIR")[selecao] else BRANCO, retangulo, 3 if nome == ("JOGAR", "INSTRUCOES", "SAIR")[selecao] else 2, border_radius=12)

        texto = FONTE.render(nome, True, BRANCO)
        TELA.blit(
            texto,
            (retangulo.centerx - texto.get_width() // 2,
             retangulo.centery - texto.get_height() // 2)
        )

    pygame.display.flip()


def reiniciar_partida():
    global pontos, inventario, missoes, missao_concluida
    global recompensa_recebida, objetos, jogador_x, jogador_z
    global mensagem, tempo_animacao

    pontos = 0
    inventario = {
        "Papel": 0,
        "Plastico": 0,
        "Metal": 0,
        "Vidro": 0
    }
    missoes = {
        "Plastico": 0,
        "Papel": 0,
        "Metal": 0
    }
    missao_concluida = ""
    recompensa_recebida = False
    mensagem = "Ajude a limpar o parque!"
    jogador_x = 0.0
    jogador_z = 0.78
    tempo_animacao = 0

    objetos = []
    for tipo in tipos:
        for i in range(8):
            objetos.append({
                "tipo": tipo,
                "x": random.uniform(-0.85, 0.85),
                "z": random.uniform(0.12, 0.85)
            })
    random.shuffle(objetos)

async def main():
    # CONTROLE DAS TELAS
    tela_atual = "menu"
    rodando = True
    opcao_menu = 0  # 0 = JOGAR, 1 = INSTRUCOES, 2 = SAIR
    diagnostico = "AGUARDANDO CLIQUE OU TECLA..."

    while rodando:
        tempo = RELOGIO.tick(60) / 1000

        for evento in pygame.event.get():
            if evento.type == pygame.QUIT:
                rodando = False

            elif evento.type == pygame.MOUSEBUTTONDOWN and evento.button == 1:
                mouse = evento.pos
                diagnostico = f"CLIQUE RECEBIDO: {mouse}"

                if tela_atual == "menu":
                    if pygame.Rect(370, 290, 260, 55).collidepoint(mouse):
                        reiniciar_partida()
                        tela_atual = "jogo"
                    elif pygame.Rect(370, 365, 260, 55).collidepoint(mouse):
                        tela_atual = "instrucoes"
                    elif pygame.Rect(370, 440, 260, 55).collidepoint(mouse):
                        rodando = False

                elif tela_atual == "instrucoes":
                    if pygame.Rect(370, 480, 260, 55).collidepoint(mouse):
                        tela_atual = "menu"

                elif tela_atual == "vitoria":
                    if pygame.Rect(370, 360, 260, 55).collidepoint(mouse):
                        reiniciar_partida()
                        tela_atual = "jogo"
                    elif pygame.Rect(370, 440, 260, 55).collidepoint(mouse):
                        tela_atual = "menu"

            elif evento.type == pygame.KEYDOWN:
                diagnostico = f"TECLA RECEBIDA: {pygame.key.name(evento.key).upper()}"
                if tela_atual == "menu":
                    if evento.key in (pygame.K_DOWN, pygame.K_s):
                        opcao_menu = (opcao_menu + 1) % 3
                    elif evento.key in (pygame.K_UP, pygame.K_w):
                        opcao_menu = (opcao_menu - 1) % 3
                    elif evento.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                        if opcao_menu == 0:
                            reiniciar_partida()
                            tela_atual = "jogo"
                        elif opcao_menu == 1:
                            tela_atual = "instrucoes"
                        else:
                            rodando = False

                elif tela_atual == "instrucoes":
                    if evento.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE, pygame.K_ESCAPE):
                        tela_atual = "menu"

                elif tela_atual == "vitoria":
                    if evento.key in (pygame.K_RETURN, pygame.K_KP_ENTER, pygame.K_SPACE):
                        reiniciar_partida()
                        tela_atual = "jogo"
                    elif evento.key == pygame.K_ESCAPE:
                        tela_atual = "menu"

                elif tela_atual == "jogo":
                    if evento.key == pygame.K_e:
                        depositar_material()
                    elif evento.key == pygame.K_ESCAPE:
                        tela_atual = "menu"

        # TELA INICIAL
        if tela_atual == "menu":
            desenhar_menu(opcao_menu)
            texto_debug = FONTE.render(diagnostico, True, AMARELO)
            TELA.blit(texto_debug, (20, ALTURA - 28))
            pygame.display.flip()

        # TELA DE INSTRUCOES
        elif tela_atual == "instrucoes":
            desenhar_parque()

            pygame.draw.rect(
                TELA, (20, 55, 35),
                (180, 120, 640, 430),
                border_radius=15
            )

            titulo = TITULO.render("COMO JOGAR", True, BRANCO)
            TELA.blit(titulo, (390, 155))

            instrucoes = [
                "W, A, S, D ou SETAS: movimentar",
                "Aproxime-se dos materiais para coleta-los",
                "Chegue perto da lixeira correspondente",
                "Pressione E para reciclar",
                "Cada material reciclado vale 20 pontos",
                "ESC: voltar ao menu"
            ]

            for i, linha in enumerate(instrucoes):
                texto = FONTE.render(linha, True, BRANCO)
                TELA.blit(texto, (250, 225 + i * 38))

            pygame.draw.rect(
                TELA, (45, 125, 65),
                (370, 480, 260, 55),
                border_radius=10
            )

            voltar = FONTE.render("VOLTAR", True, BRANCO)
            TELA.blit(voltar, (460, 497))

            pygame.display.flip()

        # JOGO
        elif tela_atual == "jogo":

            teclas = pygame.key.get_pressed()
            movimento = velocidade * tempo
            andando = False

            if teclas[pygame.K_LEFT] or teclas[pygame.K_a]:
                jogador_x -= movimento
                andando = True

            if teclas[pygame.K_RIGHT] or teclas[pygame.K_d]:
                jogador_x += movimento
                andando = True

            if teclas[pygame.K_UP] or teclas[pygame.K_w]:
                jogador_z -= movimento
                andando = True

            if teclas[pygame.K_DOWN] or teclas[pygame.K_s]:
                jogador_z += movimento
                andando = True

            if andando:
                tempo_animacao += tempo

            jogador_x = max(-0.9, min(0.9, jogador_x))
            jogador_z = max(0.12, min(0.92, jogador_z))

            coletar_objetos()

            if (
                all(
                    missoes[tipo] >= meta_missoes[tipo]
                    for tipo in meta_missoes
                )
                and all(
                    quantidade == 0
                    for quantidade in inventario.values()
                )
            ):
                tela_atual = "vitoria"

            desenhar_parque()

            elementos = []

            for objeto in objetos:
                elementos.append((objeto["z"], "objeto", objeto))

            for lixeira in lixeiras:
                elementos.append((lixeira["z"], "lixeira", lixeira))

            elementos.append((jogador_z, "jogador", None))

            elementos.sort(key=lambda item: item[0])

            for profundidade, tipo, elemento in elementos:
                if tipo == "objeto":
                    desenhar_objeto(elemento)
                elif tipo == "lixeira":
                    desenhar_lixeira(elemento)
                else:
                    desenhar_jogador()

            desenhar_interface()
            pygame.display.flip()
        elif tela_atual == "vitoria":
            desenhar_parque()

            painel = pygame.Surface((560, 300), pygame.SRCALPHA)
            painel.fill((15, 45, 25, 230))
            TELA.blit(painel, (220, 170))

            titulo = TITULO.render("MISSAO CONCLUIDA!", True, BRANCO)
            TELA.blit(titulo, (LARGURA // 2 - titulo.get_width() // 2, 220))

            texto = FONTE.render("Voce ajudou a limpar o parque!", True, BRANCO)
            TELA.blit(texto, (300, 290))

            pygame.draw.rect(TELA, VERDE, (370, 360, 260, 55), border_radius=12)
            jogar = FONTE.render("JOGAR NOVAMENTE", True, BRANCO)
            TELA.blit(jogar, (LARGURA // 2 - jogar.get_width() // 2, 375))

            pygame.draw.rect(TELA, BRANCO, (370, 440, 260, 55), border_radius=12)
            menu = FONTE.render("MENU PRINCIPAL", True, PRETO)
            TELA.blit(menu, (LARGURA // 2 - menu.get_width() // 2, 455))

            pygame.display.flip()

        await asyncio.sleep(0)

    pygame.quit()

asyncio.run(main())
